This "Weather Filled Round Corner Icons" icon pack was downloaded from https://www.reshot.com/free-svg-icons/pack/weather-filled-round-corner-icons-Y83ZNE4DTQ/ 

Please check the Reshot Icons license available at https://www.reshot.com/license/